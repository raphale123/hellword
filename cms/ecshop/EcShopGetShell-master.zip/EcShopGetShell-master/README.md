# EcShopCMS批量GetShell

## Code By:Tas9er @乐橙信安

#### 0x00 风险概述

本工具仅限授权安全测试使用,禁止未授权非法攻击站点

#### 0x01 工具使用

![01](/image/01.jpg)

![02](/image/02.png)



#### 0x02 Bug问题

有空再说，先这样。
